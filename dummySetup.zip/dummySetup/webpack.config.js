const HtmlWebpackPlugin = require('html-webpack-plugin');
var path = require('path');

module.exports = {
    mode: 'development',
    entry: './src/index.js',
    devServer: {
        contentBase: path.join(__dirname, 'dist'),
        compress: true,
        port: 9000,
        hot: true
    },
    output: {
        filename: 'index.js',
        path: __dirname + './dist'
    },
    plugins: [
        new HtmlWebpackPlugin({template: './src/index.html'})
    ],
    watch: true
};
